﻿using Sample.Wasm.ClientSideModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sample.Wasm.Views
{
    //internal class ProductSalesView
    //{

    //    ProductSalesModel model;

    //    string ToHtml()
    //    {
    //        return @$"
    //                <div class='row border rounded my-1'>
    //                    <div class='col-xl px-1 px-sm-3'><span>{model.Rep.Name}</span> sold <span class='br-{nameof(model.Quantity)}'>{model.Quantity}</span> of the <span>{model.Product.Name}</span> at $<span class='br-{nameof(model.Price)}'>{model.Price:0.##}</span> each.</div>                        
    //                </div>
    //            ";
    //    }
    //}
}
